package com.vtl.messageInvoker.servicesImpl;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;

import com.vtl.messageInvoker.services.IFileService;
import com.vtl.messageInvoker.services.IMessageService;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.util.ResponseConstants;

/**
 * @author Amit.Gupta
 * @version 1.0
 */
public class BaseUploadFacade {

	private IFileService fileService;


	private final static Logger logger = Logger
			.getLogger(BaseUploadFacade.class);

	public void startPaperProcess(String transId) {

		try {
			fileService.processMessage(transId);
		} catch (BusinessException e) {
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());
			return;
		}
	}

	public IFileService getFileService() {
		return fileService;
	}

	public void setFileService(IFileService fileService) {
		this.fileService = fileService;
	}
}