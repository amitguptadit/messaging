package com.vtl.messageInvoker.schedulers.invoker;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.vtl.msg.util.spring.CustomBeanProvider;

/**
 * @author Anurag
 * @version 1.0
 * 
 */
public class SchedulersInvoker {

	private static final Logger logger = Logger
			.getLogger(SchedulersInvoker.class);

	public static void main(String[] args) {
		SchedulersInvoker invoker = new SchedulersInvoker();
		invoker.prepareApplicationContext();
		if (CustomBeanProvider.getSpringContext() == null) {
			logger.error("ApplicationContext is not instantiated yet.");
		} else {
			logger.info("ApplicationContext instantiation is done. . .");
		}
	}

	/**
	 * This method is used to load the spring application context
	 */
	private void prepareApplicationContext() {
		try {
			ApplicationContext ctx = new ClassPathXmlApplicationContext(
					"context-scheduler.xml");
			CustomBeanProvider.setSpringContext(ctx);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error While instantiating Application Context: ", e);
		}
	}
}
