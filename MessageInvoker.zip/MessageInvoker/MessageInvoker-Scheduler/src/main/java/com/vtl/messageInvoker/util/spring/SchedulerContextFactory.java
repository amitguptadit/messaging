package com.vtl.messageInvoker.util.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SchedulerContextFactory {

	private static ApplicationContext ctx;
	private static SchedulerContextFactory ctxFactory = null;

	private SchedulerContextFactory() {
	}

	public static SchedulerContextFactory getInstance() {
		if (ctxFactory == null) {
			synchronized (SchedulerContextFactory.class) {
				if (ctxFactory == null) {
					ctxFactory = new SchedulerContextFactory();
					initializeContext();
				}
			}
		}
		return ctxFactory;
	}

	public Object getBean(String s) {
		Object bean = null;
		try {
			bean = ctx.getBean(s);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return bean;
	}

	private static void initializeContext() {
		ctx = new ClassPathXmlApplicationContext("context-scheduler.xml");
	}

	protected SchedulerContextFactory readResolve() {
		return getInstance();
	}
}
