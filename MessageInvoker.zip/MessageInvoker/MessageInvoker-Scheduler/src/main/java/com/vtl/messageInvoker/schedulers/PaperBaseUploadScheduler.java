package com.vtl.messageInvoker.schedulers;

import java.util.Calendar;
import java.util.Random;

import org.apache.log4j.Logger;

import com.vtl.messageInvoker.servicesImpl.BaseUploadFacade;

/**
 * @author Anuj.Singh
 * @version 1.0
 */
public class PaperBaseUploadScheduler {

	private final static Logger logger = Logger
			.getLogger(PaperBaseUploadScheduler.class);

	private BaseUploadFacade baseUploadFacade;
	private Integer tansLowId;
	private Integer transHighId;

	public Integer gettingTansLowId() {
		this.tansLowId = getTansLowId();
		return this.tansLowId;
	}

	public Integer gettingTransHighId() {
		this.transHighId = getTransHighId();
		return this.transHighId;
	}

	public Integer getTansLowId() {
		return tansLowId;
	}

	public void setTansLowId(Integer tansLowId) {
		this.tansLowId = tansLowId;
	}

	public Integer getTransHighId() {
		return transHighId;
	}

	public void setTransHighId(Integer transHighId) {
		this.transHighId = transHighId;
	}

	/**
	 * This method is used as a job for the base upload scheduler
	 */
	public void performTask() {
		Integer tansLowId = gettingTansLowId();
		Integer transHighId = gettingTransHighId();
		Random r = new Random();

		int transId = r.nextInt(transHighId.intValue()) + tansLowId.intValue();

		logger.info("[" + transId + "] "
				+ "PaperBaseUploadScheduler is started at "
				+ Calendar.getInstance().getTime());
		this.startPaperBaseUpload(Integer.toString(transId));

		logger.info("[" + transId + "] "
				+ "PaperBaseUploadScheduler is finished at "
				+ Calendar.getInstance().getTime());
	}

	/**
	 * This method is used to perform the steps of base uploading
	 */
	private void startPaperBaseUpload(String transId) {
		baseUploadFacade.startPaperProcess(transId);
	}

	public BaseUploadFacade getBaseUploadFacade() {
		return baseUploadFacade;
	}

	public void setBaseUploadFacade(BaseUploadFacade baseUploadFacade) {
		this.baseUploadFacade = baseUploadFacade;
	}

}
