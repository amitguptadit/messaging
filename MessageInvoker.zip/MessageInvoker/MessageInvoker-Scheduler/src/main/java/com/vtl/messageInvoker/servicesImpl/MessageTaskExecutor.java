package com.vtl.messageInvoker.servicesImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.log4j.Logger;

import com.vtl.messageInvoker.daoImpl.FileDao;
import com.vtl.messageInvoker.services.IMessageService;
import com.vtl.msg.beans.Message;
import com.vtl.msg.util.ResponseConstants;

public class MessageTaskExecutor implements Runnable
{

	public static final Logger logger = Logger
			.getLogger("MessageTaskExecutor.class");

	private Message message;
	private String transId;
	private IMessageService messageService;
	String msgStatus = "FALSE";
	//--------
	private FileDao fileDao;
	List<Message> msgList = null;
	int startIndex = 0;
	int endIndex = 0;
	public MessageTaskExecutor(List<Message> msgList, IMessageService messageService,FileDao fileDao,String transId,
			int startIndex,int endIndex) {
		super();
		this.msgList=msgList;
		this.messageService = messageService;
		this.fileDao=fileDao;
		this.transId = transId;
		this.startIndex=startIndex;
		this.endIndex=endIndex;
	}
	
	@Override
	public void run()
	{
		int recordCounter=1;
		String IsCompleteTask="FALSE"+",processed Records :"+recordCounter+", ThreadName :"+Thread.currentThread().getName();
		try
		{
			
			//write the thread job
			logger.info("[" + transId + "] "+" start Task status : "+IsCompleteTask);
			for (int i = startIndex; i < endIndex; i++)
			{
				logger.info("[" + transId + "] "
						+ " MSISDN List size for which message wants to be send..."
						+ msgList.size()+", ThreadName :"+Thread.currentThread().getName());
				
					
					Message msg =msgList.get(i);
					
					msgStatus = messageService.sendMessage(msg, transId);
	
					
					logger.info("[" + transId + "] "+"Message status: "+msgStatus+", ThreadName :"+Thread.currentThread().getName());
					
					if ("TRUE".equalsIgnoreCase(msgStatus)) {
						try {
							fileDao.updateRecord(msg,transId);
						} catch (Exception e) {
							StringWriter stack = new StringWriter();
							PrintWriter writer = new PrintWriter(stack);
							e.printStackTrace(writer);
							logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode()
									+ ":"
									+ ResponseConstants.ERR_SYSTEM_EXCEPTION
											.getResponseMsg()
									+ ":"
									+ stack.toString());
							IsCompleteTask="FALSE"+",processed Records :"+recordCounter+", ThreadName :"+Thread.currentThread().getName();
						}
					}
					recordCounter=recordCounter+1;
					IsCompleteTask="TRUE:"+",processed Records :"+recordCounter+", ThreadName :"+Thread.currentThread().getName();		
			}//End of list loop
			
		}
		catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("run()# Exception :>>" + stack.toString());
			IsCompleteTask="FALSE"+",processed Records :"+recordCounter+", ThreadName :"+Thread.currentThread().getName();
		}
		logger.info("[" + transId + "] "+" End Task status : "+IsCompleteTask);
			
	}
	
	/*public String call() throws Exception 
	{
			
	}*/

	
}
