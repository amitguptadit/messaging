package com.vtl.messageInvoker.servicesImpl;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

import com.vtl.msg.beans.Message;
import com.vtl.msg.config.FileConfig;
import com.vtl.messageInvoker.daoImpl.FileDao;

//import com.vtl.messageInvoker.daoImpl.FileDao;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.exceptions.DatabaseException;
import com.vtl.messageInvoker.services.IFileService;
import com.vtl.messageInvoker.services.IMessageService;
import com.vtl.msg.util.ResponseConstants;
import com.vtl.messageInvoker.util.spring.SchedulerContextFactory;

/**
 * @author Anurag
 * @version 1.0
 */
public class FileService implements IFileService {

	private FileDao fileDao;
	ExecutorService service = null;
	private Integer threadPoolSize;
	public Integer getThreadPoolSize() {
		return threadPoolSize;
	}

	public void setThreadPoolSize(Integer threadPoolSize) {
		this.threadPoolSize = threadPoolSize;
	}
	private IMessageService messageService;

	public IMessageService getMessageService() {
		return messageService;
	}

	public void setMessageService(IMessageService messageService) {
		this.messageService = messageService;
	}	
	private final static Logger logger = Logger.getLogger(FileService.class);

	public void processMessage(String transId) {
		List<Message> msgList = null;
		
		
		try
		{
				logger.info("[" + transId + "] "+"Executor Service[before] "+service+" ,ThreadPoolSize:"+threadPoolSize);
				if(service == null) {
					
					service = Executors.newFixedThreadPool(threadPoolSize);
					
				}
				logger.info("[" + transId + "] "+"started Executor Service[after] "+service+" ,ThreadPoolSize:"+threadPoolSize);
				
				try {			
					msgList = fileDao.getMessageList(transId);
				} catch (DatabaseException e) {
		
					StringWriter stack = new StringWriter();
					PrintWriter writer = new PrintWriter(stack);
					e.printStackTrace(writer);
					logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
							.getResponseCode()
							+ ":"
							+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
							+ ":" + stack.toString());
				}
		
				int startIndex = 0;
				int endIndex = 0;
				int size = msgList.size();
				int increment = msgList.size() / threadPoolSize;

				//------------------------------------------
				for (int i = 0; i < threadPoolSize; i++) {
					if(i == (threadPoolSize -1)) {
						endIndex = size;
					} else {
						endIndex = startIndex + increment;
					}
					
					//Future futures = service.submit(new MessageTaskExecutor(msgList,messageService,fileDao,transId,startIndex, endIndex));
					//logger.info("[" + transId + "] "+"Task status: "+futures.get().toString());
					service.execute(new MessageTaskExecutor(msgList,messageService,fileDao,transId,startIndex, endIndex));
					startIndex = endIndex;
				}
				
				//------------------------------
				
		/*		if (msgList != null && msgList.size() > 0) {
					logger.info("[" + transId + "] "
							+ " MSISDN List size for which message wants to be send..."
							+ msgList.size());
					
					
					for (Message msg : msgList) {
						
						
						Future future = service.submit(new MessageTaskExecutor(msg,transId,messageService));
						//msgStatus = messageService.sendMessage(msg, transId);
		
						
						logger.info("[" + transId + "] "+"Message status: "+future.get().toString());
						try {
							//Thread.sleep(500);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
						if ("TRUE".equalsIgnoreCase(future.get().toString())) {
							try {
								fileDao.updateRecord(msg,transId);
							} catch (DatabaseException e) {
								StringWriter stack = new StringWriter();
								PrintWriter writer = new PrintWriter(stack);
								e.printStackTrace(writer);
								logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
										.getResponseCode()
										+ ":"
										+ ResponseConstants.ERR_SYSTEM_EXCEPTION
												.getResponseMsg()
										+ ":"
										+ stack.toString());
							}
						}
					}
				}//End of list loop
				*/
		}//End of first try
		catch(Exception ex)
		{
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			ex.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());
		}
	}

	public List<String> downloadFile(FileConfig fileConfig, Calendar currCal,
			String remoteSourceFilePath, String remoteBackupFilePath,
			String localFilePath, final String fileName,
			final String fileExtension) throws BusinessException {

		List<String> fileList = new ArrayList<String>();
		// For LocalTest uncomment below line and comment it our all below
		// section
		// fileList.add("2014-02-27_01.csv");

		Session session = null;
		Channel channel = null;
		try {
			JSch ssh = (JSch) SchedulerContextFactory.getInstance().getBean(
					"jsch");
			JSch.setConfig("StrictHostKeyChecking", "no");
			session = ssh.getSession(fileConfig.getScpUserName(),
					fileConfig.getScpHost(), fileConfig.getScpPort());
			session.setPassword(fileConfig.getScpPassword());
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			logger.info("SFTP Login to " + fileConfig.getScpHost()
					+ " is successful");
			ChannelSftp channelSftp = (ChannelSftp) channel;

			Boolean isSourcePathExixt = Boolean.FALSE;

			SftpATTRS sourcePathAttrs = channelSftp.stat(fileConfig
					.getRemoteFileSourcePath());

			if (sourcePathAttrs != null) {
				isSourcePathExixt = Boolean.TRUE;
			} else {
				logger.error(ResponseConstants.ERR_DIRECTORY_NOT_EXIST
						.getResponseCode()
						+ ":"
						+ ResponseConstants.ERR_DIRECTORY_NOT_EXIST
								.getResponseMsg()
						+ fileConfig.getRemoteFileSourcePath());
			}

			if (isSourcePathExixt) {
				@SuppressWarnings("unchecked")
				Vector<LsEntry> remoteFileVector = channelSftp.ls(fileConfig
						.getRemoteFileSourcePath()
						+ File.separator
						+ fileName
						+ "*" + fileExtension);
				if (remoteFileVector != null && remoteFileVector.size() > 0) {
					Enumeration<LsEntry> enumLsEntry = remoteFileVector
							.elements();
					while (enumLsEntry.hasMoreElements()) {
						try {
							LsEntry entry = (LsEntry) enumLsEntry.nextElement();
							logger.info("File : " + entry.getFilename()
									+ " is present at SCP location - "
									+ fileConfig.getRemoteFileSourcePath());
							channelSftp.get(
									fileConfig.getRemoteFileSourcePath()
											+ File.separator
											+ entry.getFilename(),
									localFilePath);
							logger.info("File : " + entry.getFilename()
									+ " is downloaded at the local location - "
									+ localFilePath);
							fileList.add(entry.getFilename());
						} catch (SftpException e) {
							StringWriter stack = new StringWriter();
							PrintWriter writer = new PrintWriter(stack);
							e.printStackTrace(writer);
							logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode()
									+ ":"
									+ ResponseConstants.ERR_SYSTEM_EXCEPTION
											.getResponseMsg()
									+ ":"
									+ stack.toString());
						}

					}
				}
			}
		} catch (JSchException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (SftpException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (Exception e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}
		return fileList;
	}

	public List<String> downloadPaperFile(FileConfig fileConfig,
			Calendar currCal, String remoteSourceFilePath,
			String remoteBackupFilePath, String localFilePath,
			final String fileName, final String fileExtension)
			throws BusinessException {

		List<String> fileList = new ArrayList<String>();
		// For LocalTest uncomment below line and comment it our all below
		// section
		// fileList.add("2014-02-27_01.csv");

		Session session = null;
		Channel channel = null;
		try {
			JSch ssh = (JSch) SchedulerContextFactory.getInstance().getBean(
					"jsch");
			JSch.setConfig("StrictHostKeyChecking", "no");
			session = ssh.getSession(fileConfig.getScpUserNamePaper(),
					fileConfig.getScpHostPaper(), fileConfig.getScpPortPaper());
			session.setPassword(fileConfig.getScpPasswordPaper());
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			logger.info("SFTP Login to " + fileConfig.getScpHostPaper()
					+ " is successful");
			ChannelSftp channelSftp = (ChannelSftp) channel;

			Boolean isSourcePathExixt = Boolean.FALSE;

			SftpATTRS sourcePathAttrs = channelSftp.stat(fileConfig
					.getRemotePaperFileSourcePath());

			if (sourcePathAttrs != null) {
				isSourcePathExixt = Boolean.TRUE;
			} else {
				logger.error(ResponseConstants.ERR_DIRECTORY_NOT_EXIST
						.getResponseCode()
						+ ":"
						+ ResponseConstants.ERR_DIRECTORY_NOT_EXIST
								.getResponseMsg()
						+ fileConfig.getRemotePaperFileSourcePath());
			}

			if (isSourcePathExixt) {
				@SuppressWarnings("unchecked")
				Vector<LsEntry> remoteFileVector = channelSftp.ls(fileConfig
						.getRemotePaperFileSourcePath()
						+ File.separator
						+ fileName + "*" + fileExtension);
				if (remoteFileVector != null && remoteFileVector.size() > 0) {
					Enumeration<LsEntry> enumLsEntry = remoteFileVector
							.elements();
					while (enumLsEntry.hasMoreElements()) {
						try {
							LsEntry entry = (LsEntry) enumLsEntry.nextElement();
							logger.info("Paper File : " + entry.getFilename()
									+ " is present at SCP location - "
									+ fileConfig.getRemotePaperFileSourcePath());
							channelSftp.get(
									fileConfig.getRemotePaperFileSourcePath()
											+ File.separator
											+ entry.getFilename(),
									localFilePath);
							logger.info("Paper File : " + entry.getFilename()
									+ " is downloaded at the local location - "
									+ localFilePath);
							fileList.add(entry.getFilename());
						} catch (SftpException e) {
							StringWriter stack = new StringWriter();
							PrintWriter writer = new PrintWriter(stack);
							e.printStackTrace(writer);
							logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode()
									+ ":"
									+ ResponseConstants.ERR_SYSTEM_EXCEPTION
											.getResponseMsg()
									+ ":"
									+ stack.toString());
						}

					}
				}
			}
		} catch (JSchException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (SftpException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (Exception e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}
		return fileList;
	}

	public Boolean moveFiles(String remoteFilePath, String localFilePath,
			String... files) {
		Boolean flag = Boolean.FALSE;
		for (String fileName : files) {
			File sourceFile = new File(remoteFilePath + File.separator
					+ fileName);
			File destinationFile = new File(localFilePath + File.separator
					+ fileName);
			flag = sourceFile.renameTo(destinationFile);
		}
		return flag;
	}

	public FileDao getFileDao() {
		return fileDao;
	}

	public void setFileDao(FileDao fileDao) {
		this.fileDao = fileDao;
	}

}
