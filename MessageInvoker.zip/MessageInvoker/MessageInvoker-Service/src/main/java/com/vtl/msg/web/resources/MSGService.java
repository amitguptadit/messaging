package com.vtl.msg.web.resources;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HEAD;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sun.jersey.api.core.HttpContext;
import com.vtl.msg.beans.ServiceResponse;
import com.vtl.msg.beans.ValidationResponse;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.exceptions.DatabaseException;
import com.vtl.msg.services.IMSG;
import com.vtl.msg.services.IValidationService;
import com.vtl.msg.servicesImpl.ValidationService;
import com.vtl.msg.util.ResponseConstants;
import com.vtl.msg.util.spring.CustomBeanProvider;

@Component
@Path("/")
@Scope("request")
public class MSGService {

	private static final Logger logger = Logger.getLogger(MSGService.class);

	@Autowired
	private IValidationService validationService;

	public MSGService() {
	}

	@Path("MessageInvokerProcess")
	@HEAD
	@Produces(MediaType.APPLICATION_XML)
	public Response processPPS() {
		ServiceResponse serviceResponse = new ServiceResponse();
		serviceResponse.setResponseCode(ResponseConstants.SUCCESS_MESSAGE
				.getResponseCode());
		serviceResponse.setResponseMsg(ResponseConstants.SUCCESS_MESSAGE
				.getResponseMsg());
		return Response.status(Response.Status.OK).entity(serviceResponse)
				.type(MediaType.APPLICATION_XML).build();
	}

	@Path("MessageInvokerProcess")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public Response processMessageInvoker(@Context HttpContext httpContext,
			@QueryParam("msisdn") String msisdn, @QueryParam("cli") String cli,
			@QueryParam("content") String content,
			@QueryParam("username") String username,
			@QueryParam("password") String password,
			@Context HttpServletRequest httpServletRequest)
			throws BusinessException, DatabaseException, Exception {

		IMSG imsg = CustomBeanProvider.getBean("imsg");
		Integer tansLowId = imsg.gettingTansLowId();
		Integer transHighId = imsg.gettingTransHighId();
		Random r = new Random();

		int transId = r.nextInt(transHighId.intValue()) + tansLowId.intValue();
		ServiceResponse serviceResponse = new ServiceResponse();
		msisdn = msisdn != null ? msisdn : "NA";
		cli = cli != null ? cli : "NA";
		content = content != null ? content : "NA";

		username = username != null ? username : "NA";
		password = password != null ? password : "NA";

		// validationService

		logger.info("[" + transId + "] " + "MSISDN : " + msisdn + "  CLI : "
				+ cli + "  Content : " + content);
		ValidationService validationService = CustomBeanProvider
				.getBean("validationService");

		ValidationResponse validationResponse = validationService
				.validateParam(transId, msisdn, cli, content, username,
						password);

		logger.info("[" + transId + "] " + "Is User Validated  : "
				+ validationResponse.getValidateRespFlag());
		if (validationResponse.getValidateRespFlag()) {

			String isMessageSent = imsg.sendMessage(Integer.toString(transId),
					msisdn, content, cli).trim();
			if (isMessageSent.equalsIgnoreCase("true")
					|| isMessageSent.equals("true")) {
				serviceResponse
						.setResponseCode(ResponseConstants.SUCCESS_MESSAGE
								.getResponseCode());
				serviceResponse
						.setResponseMsg(ResponseConstants.SUCCESS_MESSAGE
								.getResponseMsg());
				
				serviceResponse.setTransId(Integer.toString(transId));

				logger.info("[" + transId + "] "
						+ "[Message  successfuly has been sent on MSISDN : " + msisdn
						+ " , isMessageSent: " + isMessageSent);
			} else {

				serviceResponse
						.setResponseCode(ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseCode());
				serviceResponse
						.setResponseMsg(ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseMsg());

				logger.info("[" + transId + "] "
						+ "[Message  has not been sent on MSISDN : " + msisdn
						+ " , isMessageSent:" + isMessageSent);

			}

		}
		else {

			serviceResponse.setResponseCode(validationResponse
					.getValidateRespCode());
			serviceResponse.setResponseMsg(validationResponse
					.getServiceResponseMsg());

		}

		return Response.status(Response.Status.OK).entity(serviceResponse)
				.type(MediaType.APPLICATION_XML).build();

	}

}
