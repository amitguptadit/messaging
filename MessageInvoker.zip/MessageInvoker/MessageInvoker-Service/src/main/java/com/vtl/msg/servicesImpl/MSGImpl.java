package com.vtl.msg.servicesImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.msg.services.IMSG;
import com.vtl.msg.util.UMFMessaging;

public class MSGImpl implements IMSG {
	public static final Logger logger = Logger.getLogger("MSGImpl.class");
	@Autowired
	private UMFMessaging umfMessaging;

	private Integer tansLowId;
	private Integer transHighId;
	private String umfCliName = null;
	private List<String> umfCliNameList = null;

	private String umfUserName = null;
	private List<String> umfUserNameList = null;

	private String umfPassword = null;
	private List<String> umfPasswordList = null;

	

	public void init() {

		if (umfCliName != null) {

			String[] arrAllowedClis = umfCliName.split(",");
			for (String allowedCli : arrAllowedClis) {
				umfCliNameList.add(allowedCli);
			}
		}

		if (umfUserName != null) {

			String[] arrAllowedUser = umfUserName.split(",");
			for (String allowedUser : arrAllowedUser) {
				umfUserNameList.add(allowedUser);
			}
		}

		if (umfPassword != null) {

			String[] arrAllowedPwd = umfPassword.split(",");
			for (String allowedPwd : arrAllowedPwd) {
				umfPasswordList.add(allowedPwd);
			}
		}
	}

	@Override
	public String sendMessage(String transId, String msisdn, String msgContent,
			String cli_name) {

		String messageStatus = "FALSE";
		try {

			String snscUsername = "", smscPassword = "";

			int inx = umfCliNameList.indexOf(cli_name.trim());
			snscUsername = umfUserNameList.get(inx);
			smscPassword = umfPasswordList.get(inx);

			messageStatus = umfMessaging.callUMFInterface(msisdn, msgContent,
					transId, cli_name, snscUsername, smscPassword).toString();

			logger.info("[" + transId + "] " + " SendMessage() MSISDN :"
					+ msisdn + " Content :" + msgContent
					+ " Is Message Send : " + messageStatus);
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("SendMessage() # Exception : >> " + stack.toString());
		}
		return messageStatus;

	}

	@Override
	public Boolean checkUmfUserName(int transId, String userName) {
		Boolean isValid = Boolean.FALSE;
		try {
			userName = userName.trim();
			isValid = umfUserNameList.contains(userName);
			logger.info("[" + transId + "] "
					+ "UMF UserName :" + userName
					+ ", isValid : " + isValid);
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("CheckUmfUserName() # Exception : >> " + stack.toString());
		}
		return isValid;

	}

	@Override
	public Boolean checkUmfPassword(int transId, String password) {
		Boolean isValid = Boolean.FALSE;
		try {
			password = password.trim();
			isValid = umfPasswordList.contains(password);
			logger.info("[" + transId + "] "
					+ "UMF Password :" + password
					+ ", isValid : " + isValid);
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("CheckUmfUserName() # Exception : >> " + stack.toString());
		}
		return isValid;
	}

	@Override
	public Integer gettingTansLowId() {
		this.tansLowId = getTansLowId();
		return this.tansLowId;
	}

	@Override
	public Integer gettingTransHighId() {
		this.transHighId = getTransHighId();
		return this.transHighId;
	}
	
	public Integer getTansLowId() {
		return tansLowId;
	}

	public void setTansLowId(Integer tansLowId) {
		this.tansLowId = tansLowId;
	}

	public Integer getTransHighId() {
		return transHighId;
	}

	public void setTransHighId(Integer transHighId) {
		this.transHighId = transHighId;
	}

	public UMFMessaging getUmfMessaging() {
		return umfMessaging;
	}

	public void setUmfMessaging(UMFMessaging umfMessaging) {
		this.umfMessaging = umfMessaging;
	}

	public String getUmfCliName() {
		return umfCliName;
	}

	public void setUmfCliName(String umfCliName) {
		this.umfCliName = umfCliName;
	}

	public List<String> getUmfCliNameList() {
		return umfCliNameList;
	}

	public void setUmfCliNameList(List<String> umfCliNameList) {
		this.umfCliNameList = umfCliNameList;
	}

	public String getUmfUserName() {
		return umfUserName;
	}

	public void setUmfUserName(String umfUserName) {
		this.umfUserName = umfUserName;
	}

	public List<String> getUmfUserNameList() {
		return umfUserNameList;
	}

	public void setUmfUserNameList(List<String> umfUserNameList) {
		this.umfUserNameList = umfUserNameList;
	}

	public String getUmfPassword() {
		return umfPassword;
	}

	public void setUmfPassword(String umfPassword) {
		this.umfPassword = umfPassword;
	}

	public List<String> getUmfPasswordList() {
		return umfPasswordList;
	}

	public void setUmfPasswordList(List<String> umfPasswordList) {
		this.umfPasswordList = umfPasswordList;
	}

}
