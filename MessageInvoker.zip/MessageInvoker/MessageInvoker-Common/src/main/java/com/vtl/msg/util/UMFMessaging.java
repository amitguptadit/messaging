package com.vtl.msg.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.bind.JAXBContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.msg.config.UmfConfig;

public class UMFMessaging {

	public static final Logger logger = Logger.getLogger("UMFMessaging.class");

	@Autowired
	private UmfConfig umfConfig;

	public Boolean callUMFInterface(String msisdn, String umfMessageToSend,
			String transId, String appName, String userName,
			String password) {
		Boolean flag = Boolean.FALSE;
		HttpURLConnection connection = null;
		try {

			URL url = new URL(umfConfig.getUmfInterface() + appName
					+ "/requests");
			SmsSenderServiceXml obj = new SmsSenderServiceXml();

			String prefixAdd = "91";
			if (msisdn.length() == 10) {
				msisdn = (new StringBuilder()).append(prefixAdd).append(msisdn)
						.toString();
			}
			obj.setAddress("tel:+" + msisdn);
			obj.setOutboundSMSTextMessage(umfMessageToSend);
			obj.setSenderAddress(appName);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("username", userName);
			connection.setRequestProperty("password", password);
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", "application/xml");

			JAXBContext jc = JAXBContext.newInstance(obj.getClass());
			OutputStream xml = connection.getOutputStream();
			jc.createMarshaller().marshal(obj, xml);
			logger.info("[" + transId + "] "
					+ "XML to be sent in request body is : " + xml);

			if (connection.getResponseCode() == 200) {
				flag = Boolean.TRUE;
				BufferedReader in = null;
				in = new BufferedReader(new InputStreamReader(
						connection.getInputStream()));
				String response = null;

				while ((response = in.readLine()) != null) {
					logger.info("[" + transId + "] " + response);
				}
			} else if (connection.getResponseCode() == 400) {
				flag = Boolean.FALSE;
				logger.error("[" + transId + "] " + " Bad request");
				BufferedReader in = null;
				in = new BufferedReader(new InputStreamReader(
						connection.getInputStream()));
				String response = null;

				while ((response = in.readLine()) != null) {
					logger.info(response);
				}
			} else {
				flag = Boolean.FALSE;
				logger.error("[" + transId + "] " + " Exception code :"
						+ connection.getResponseCode());
			}
		} catch (Exception e) {
			flag = Boolean.FALSE;
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(stack.toString());
		} finally {
			connection.disconnect();
		}
		return flag;
	}

	public UmfConfig getUmfConfig() {
		return umfConfig;
	}

	public void setUmfConfig(UmfConfig umfConfig) {
		this.umfConfig = umfConfig;
	}

}
