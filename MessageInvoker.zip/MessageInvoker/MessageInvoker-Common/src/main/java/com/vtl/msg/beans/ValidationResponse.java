package com.vtl.msg.beans;

public class ValidationResponse {

	private String validateRespCode;
	private Boolean validateRespFlag;
	private String serviceResponseMsg;

	public String getValidateRespCode() {
		return validateRespCode;
	}

	public void setValidateRespCode(String validateRespCode) {
		this.validateRespCode = validateRespCode;
	}

	public Boolean getValidateRespFlag() {
		return validateRespFlag;
	}

	public void setValidateRespFlag(Boolean validateRespFlag) {
		this.validateRespFlag = validateRespFlag;
	}

	public String getServiceResponseMsg() {
		return serviceResponseMsg;
	}

	public void setServiceResponseMsg(String serviceResponseMsg) {
		this.serviceResponseMsg = serviceResponseMsg;
	}

}
