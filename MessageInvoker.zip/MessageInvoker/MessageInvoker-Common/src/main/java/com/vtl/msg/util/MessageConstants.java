package com.vtl.msg.util;
public enum MessageConstants
{
		SERVICE_MESSAGE_MSG1("MSG001","Custom message need to be handle,in case Failure Transaction  from IN  API's ."),
		SERVICE_MESSAGE_MSG2("MSG002","Custom message need to be handle,in case of Not Go for FRC because AllowMultiple : N  and IN Offer Id is not match "),
		SERVICE_MESSAGE_MSG3("MSG003","Custom message need to be handle..!!"),;

		private final String responseCode;
		private final String responseMsg;

		private MessageConstants(String responseCode, String responseMsg) {
			this.responseCode = responseCode;
			this.responseMsg = responseMsg;
		}
		public String getResponseCode() {
			return responseCode;
		}
		public String getResponseMsg() {
			return responseMsg;
		}


	}
