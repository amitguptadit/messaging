package com.vtl.msg.exceptions;

/**
 * @author Amit Gupta
 * @version 1.0
 *
 *          DatabaseException is the base class for all database exceptions
 *          thrown within PPS applications.
 *
 */
public class DatabaseException extends Exception {

	private static final long serialVersionUID = -2061260163718214468L;
	private String errCode;
	private String errMsg;

	public DatabaseException() {
		super();
	}

	public DatabaseException(Throwable cause) {
		super(cause);
	}

	public DatabaseException(String errCode, String errMsg, Throwable cause) {
		super("[" + errCode + ":" + errMsg + "]", cause);
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public DatabaseException(String errCode, String errMsg) {
		super("[" + errCode + ":" + errMsg + "]");
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

}
