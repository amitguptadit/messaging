package com.vtl.msg.services;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.exceptions.DatabaseException;




public interface ICacheService {

	/**
	 * This method is used to cache the PPS Master Data
	 *
	 * @return
	 * @throws BusinessException
	 * @throws DatabaseException
	 */
	Boolean cachePPSServicePlanConfiguration() throws BusinessException, DatabaseException;


}
