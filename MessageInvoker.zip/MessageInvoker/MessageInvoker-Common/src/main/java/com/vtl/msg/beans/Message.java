package com.vtl.msg.beans;

public class Message {
	private int id;
	private String msisdn;
	private String cli;
	private String content;
	private String createdDate;
	private String lastModificationDate;
	private boolean isMessageSent;
	private String messageSentDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCli() {
		return cli;
	}

	public void setCli(String cli) {
		this.cli = cli;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModificationDate() {
		return lastModificationDate;
	}

	public void setLastModificationDate(String lastModificationDate) {
		this.lastModificationDate = lastModificationDate;
	}

	public boolean isMessageSent() {
		return isMessageSent;
	}

	public void setMessageSent(boolean isMessageSent) {
		this.isMessageSent = isMessageSent;
	}

	public String getMessageSentDate() {
		return messageSentDate;
	}

	public void setMessageSentDate(String messageSentDate) {
		this.messageSentDate = messageSentDate;
	}

}
