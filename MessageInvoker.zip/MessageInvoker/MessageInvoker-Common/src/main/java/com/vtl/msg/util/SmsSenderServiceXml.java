package com.vtl.msg.util;

import java.net.URI;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "outboundSMSMessageRequest")
public class SmsSenderServiceXml {

	private String address;
	private String senderAddress;
	private String outboundSMSTextMessage;
	private String clientCorrelator;
	private URI receiptRequest;
	private String callBackData;
	private String senderName;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSenderAddress() {
		return senderAddress;
	}

	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}

	public String getOutboundSMSTextMessage() {
		return outboundSMSTextMessage;
	}

	public void setOutboundSMSTextMessage(String outboundSMSTextMessage) {
		this.outboundSMSTextMessage = outboundSMSTextMessage;
	}

	public String getClientCorrelator() {
		return clientCorrelator;
	}

	public void setClientCorrelator(String clientCorrelator) {
		this.clientCorrelator = clientCorrelator;
	}

	public URI getReceiptRequest() {
		return receiptRequest;
	}

	public void setReceiptRequest(URI receiptRequest) {
		this.receiptRequest = receiptRequest;
	}

	public String getCallBackData() {
		return callBackData;
	}

	public void setCallBackData(String callBackData) {
		this.callBackData = callBackData;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

}
