package com.vtl.msg.cache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.vtl.msg.util.MSGConstants;
public class MSGCacheManager {

		private static CacheManager cacheManager = null;

		static {
			cacheManager = CacheManager.create();
		}

		/**
		 * @param cacheKey
		 * @return
		 */
		public Object getObject(String cacheKey) {
			Cache cache = cacheManager.getCache(Cache.DEFAULT_CACHE_NAME);
			return cache.get(cacheKey).getObjectValue();
		}

		/**
		 * @param cacheKey
		 * @param cacheValue
		 */
		public void putObject(Object cacheKey, Object cacheValue) {
			Cache cache = cacheManager.getCache(Cache.DEFAULT_CACHE_NAME);
			cache.put(new Element(cacheKey, cacheValue));
		}

		/**
		 * This method is used to cache the RechargeWallet base data
		 *
		 * @param key
		 * @param value
		 */
		public void putBaseInCache(String key, String value) {
			Cache cache = cacheManager.getCache(MSGConstants.RECHARGEWALLET_BASE_MASTER_CACHE);

			if (cache != null) {
				cache.put(new Element(key, value));
			}
		}


		/**
		 * This method is used to get the cached Base data details against the
		 * MSISDn Number from Base master Cache
		 *
		 * @param cacheKey
		 * @return
		 */
		public String getBaseFromCache(String cacheKey) {
			Cache cache = cacheManager.getCache(MSGConstants.RECHARGEWALLET_BASE_MASTER_CACHE);
			String value = null;
			if (cache != null) {
				Element element = cache.get(cacheKey);
				if (element != null) {
					value = (String) element.getObjectValue();
				}
			}
			return value;
		}

		/**
		 * This method is used to clear the Base Master Cache
		 *
		 */
		public void clearBaseCache() {
			Cache cache = cacheManager.getCache(MSGConstants.RECHARGEWALLET_BASE_MASTER_CACHE);
			if (cache != null) {
				synchronized (this) {
					cache.removeAll();
				}
			}
		}

		/**
		 * This method is used to check whether Base Master table is cached
		 *
		 * @return
		 */
		public Boolean isBaseCached() {
			Cache cache = cacheManager.getCache(MSGConstants.RECHARGEWALLET_BASE_MASTER_CACHE);
			if (cache == null) {
				return Boolean.FALSE;
			}
			if (cache != null && cache.getKeys() == null) {
				return Boolean.FALSE;
			}
			if (cache != null
					&& (cache.getKeys() != null && cache.getKeys().size() == 0)) {
				return Boolean.FALSE;
			}
			return Boolean.TRUE;
		}

	}
